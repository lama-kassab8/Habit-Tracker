import json

class FileHandler:


    def load_habits(self):
        try:
            with open("habits.json", "r") as f:
                habits= json.load(f)
        except (FileNotFoundError, json.JSONDecodeError) as e:
            print(f"{e}: Problem loading your file.")
            return[]
    
    def save_habits(self, habits):
        try:
            with open("habits.json", "w") as f:
                json.dump(habits, f, indent= 4)
        except IOError as e:
            print(e)
            
