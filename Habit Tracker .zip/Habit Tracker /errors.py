class FileNotFoundError(Exception):
    pass

class HabitNotFoundError(Exception):
    pass

class HabitAlreadyCompletedError(Exception):
    def __str__(self):
        return "The habit you entered is already completed."

class ValueError(Exception):
    def __str__(self):
        return "Please, input only a number from 1 to 4."

class IOError(Exception):
    def __str__(self):
        return"There was a problem with handling the file"