from datetime import date
from errors import HabitNotFoundError, HabitAlreadyCompletedError
from file_handler import FileHandler
from habit import Habit


def add_habit(habit):
            habits=load_habits()
            if isinstance(habit,Habit):
                habits.append({
                    'title': habit.title,
                    'frequency': habit.frequency,
                    'completed_dates': habit.completed_dates
                })
            save_habits(habits)
            print(f"{habit.title} has been added successfully!")

def mark_habit_done():
            name=input("What's the title of the habit that you want to mark as done? ")
            today= date.today().isoformat()
            habits=load_habits()
            found= False

            for h in habits:
                if h['title']==name:
                    found=True
                    if today in h['completed_dates']:
                        raise HabitAlreadyCompletedError
                    else:
                        done= Habit.from_dict(h)
                        done.mark_done()
                        h['completed_dates']= done.completed_dates
                        save_habits(habits)
                        print(f"{name} has been marked as done!")
                        return
            if not found:
                raise HabitNotFoundError

def view_all_habits():
        habits=load_habits()
        for habit in habits:
            print(f"- {habit['title']} {habit['frequency']}: {habit['completed_dates']}")

def load_habits():
        return FileHandler().load_habits()
    
def save_habits(habits):
    return FileHandler().save_habits(habits)


print("Welcome to the Habit Tracker Program!\n")




while True:
    try:
        operation= int(input("Choose the number of the operation you want to do: \n1. Add habit\n2. Mark habit as done\n3. view all habits \n4. exit"))
    
    except ValueError:
            print("Invalid input. Please enter a number from 1 to 4.")
            continue
    
    if operation==1:
        title= input("Enter the title of your habit: ")
        frequency= input("How often do you want to do this habit? ")
        habit=Habit(title, frequency)
        add_habit(habit)
            
    elif operation==2:
        try:
            mark_habit_done()
        except (HabitNotFoundError, HabitAlreadyCompletedError) as e:
            print(e)

    elif operation==3:
        view_all_habits()

    elif operation==4:
        break

    else:
        print("There was a problem handling the file.")


