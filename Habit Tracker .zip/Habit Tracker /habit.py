from datetime import date
from errors import FileNotFoundError, HabitNotFoundError, HabitAlreadyCompletedError
from file_handler import FileHandler

class Habit:

    def __init__(self, title, frequency, completed_dates= None):
        self.title= title
        self.frequency= frequency
        self.completed_dates= completed_dates if completed_dates is not None else []
    
    
    def mark_done(self):
        file_handler= FileHandler()
        habits=file_handler.load_habits()
        today= date.today().isoformat()
        habit_found= False

        for habit in habits:
            if habit['title']==self.title:
                habit_found=True
                if today in habit['completed_dates']:
                    raise HabitAlreadyCompletedError
                else:
                    habit['completed_dates'].append(today)
                break

        if not habit_found:
            raise HabitNotFoundError
        file_handler.save_habits(habits)

    def to_dict(self):
        return{
            "title": self.title,
            "frequency": self.frequency,
            "completed_dates": self.completed_dates
        }

    @classmethod
    def from_dict(cls, data):
        return cls(
            title=data["title"],
            frequency=data["frequency"],
            completed_dates=data.get("completed_dates", [])
        )


